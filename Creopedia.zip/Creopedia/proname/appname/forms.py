from django import forms
from django.contrib.auth.models import User 
from .models import Categories, Product


class CategoriesForm(forms.ModelForm): 
  
    class Meta: 
        model = Categories 
        fields = '__all__'

# class ProductForm(forms.ModelForm): 
  
#     class Meta: 
#         model = Product 
#         fields = '__all__'

class ProductForm(forms.ModelForm):

    name = forms.CharField(max_length=50)
    image = forms.ImageField(widget=forms.ClearableFileInput(attrs={'multiple': True}))
    price = forms.IntegerField()
    features = forms.CharField(max_length=50)
    description = forms.Textarea()
    
    class Meta:
        model = Product
        fields = ('name', 'image', 'price','features','description')