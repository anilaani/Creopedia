from django.shortcuts import render
from django.http import HttpResponse
from .forms import CategoriesForm,ProductForm
from .models import Categories, Product
from django.views import View
from django.contrib import messages
from django.views.generic.list import ListView
from django.http import HttpResponseRedirect
from django.shortcuts import redirect


def index(request):
    shelf = Categories.objects.all()
    shelf_product = Product.objects.all()

    return render(request, 'product/home.html', {'shelf': shelf,'shelf_product': shelf_product})
def CreateCategory(request):
    upload = CategoriesForm()
    if request.method == 'POST':
        upload = CategoriesForm(request.POST, request.FILES)
        if upload.is_valid():
            upload.save()
            return redirect('index')
        else:
            return HttpResponse("""your form is wrong, reload on <a href = "{{ url : 'index'}}">reload</a>""")
    else:
        return render(request, 'product/upload_form.html', {'upload_form':upload})

def UpdateCategory(request, category_id):
    category_id = int(category_id)
    try:
        category = Categories.objects.get(id = category_id)
    except Categories.DoesNotExist:
        return redirect('index')
    form = CategoriesForm(request.POST or None, instance = category)
    if form.is_valid():
       form.save()
       return redirect('index')
    return render(request, 'product/update_form.html', {'upload_form':form})

def CreateProduct(request):
    uploadform = ProductForm()
    if request.method == 'POST':
        uploadform = ProductForm(request.POST, request.FILES)
        if uploadform.is_valid():
            uploadform.save()
            return redirect('index')
        else:
            return HttpResponse("""your form is wrong, reload on <a href = "{{ url : 'index'}}">reload</a>""")
    else:
        return render(request, 'product/upload_product.html', {'upload_forms':uploadform})


def UpdateProduct(request, product_id):
    product_id = int(product_id)
    try:
        product = Product.objects.get(id = product_id)
    except Product.DoesNotExist:
        return redirect('index')
    form = ProductForm(request.POST or None, instance = product)
    if form.is_valid():
       form.save()
       return redirect('index')
    return render(request, 'product/update_product.html', {'upload_forms':form})