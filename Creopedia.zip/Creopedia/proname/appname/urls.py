from django.urls import path,include
from . import views
from . import views
from proname.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name = 'index'),
    path('create/', views.CreateCategory, name = 'create_category'),
    path('update/<int:category_id>', views.UpdateCategory,name = 'update'),
    path('create_product/', views.CreateProduct, name = 'create_product'),
    path('update_product/<int:product_id>', views.UpdateProduct,name = 'update_product'),
    
]

if DEBUG:
    urlpatterns += static(STATIC_URL, document_root = STATIC_ROOT)
    urlpatterns += static(MEDIA_URL, document_root = MEDIA_ROOT)
