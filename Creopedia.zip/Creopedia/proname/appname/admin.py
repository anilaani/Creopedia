from django.contrib import admin
from appname.models import Categories, Product
# Register your models here.
admin.site.register(Categories)
admin.site.register(Product)
